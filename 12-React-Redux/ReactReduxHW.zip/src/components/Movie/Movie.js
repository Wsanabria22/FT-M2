import React from 'react';
import { connect } from 'react-redux';
import { getMovieDetail, clearDetail } from '../../actions/index';

import './Movie.css';

class Movie extends React.Component {

componentDidMount(){
    const movieId = this.props.match.params.id
    //this.props.loading()
    this.props.getMovieDetail(movieId)
}

/*
REACT PURO

DidMount
useEffect(() => {
     dispatch(getMovieDetail(movieId))
}, [])

DidUpdate
useEffect(() => {
   dispatch(getMovieDetail(movieId))
}, [movies])

useEffect(() => {
    dispatch(getMovieDetail(movieId)),
   return () => dispatch(clearDetail())
}, [movies])


*/


componentWillUnmount() {
    this.props.clearDetail()
}
    render() {
        return (
            <div className="movie-detail">
               <h2> {`Titulo: ${this.props.movies.Title}`}</h2>
               <img src={this.props.movies.Poster} alt="Img not found"/>
                <h4>{`Año: ${this.props.movies.Year}`}</h4>
                <h4>{`Duración: ${this.props.movies.Runtime}`}</h4>
                <h4>{`Elenco: ${this.props.movies.Actors}`}</h4>
                <h4>{`Director: ${this.props.movies.Director}`}</h4>
                <h4>{`Premios: ${this.props.movies.Awards}`}</h4>
                <h4>{`Ciudad: ${this.props.movies.Country}`}</h4>

            </div>
        );
    }
}

function mapStateToProps(state){
return{
    movies: state.moviesDetail
}
}

function mapDispatchToProps(dispatch){
    return {
        getMovieDetail: id => dispatch(getMovieDetail(id)),
        clearDetail: () => dispatch(clearDetail())
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Movie);